\# Valence Ops — Clinic Qualification, Disqualification & Wedge Routing Playbook

\*Last updated: \[add date\] · Owner: Tilak & co-founder\*

\---

\#\# 0\. Core operating rule

The entry wedge is \*\*diagnosed, never pre-selected\*\*. For every clinic, find the earliest  
provable stage in the Revenue OS funnel where money is visibly dying, and lead with the  
offer that fixes that stage. Dead-lead reactivation is one wedge among many — not the  
default.

When multiple breaks exist in the same clinic, prioritize the one that is:  
1\. Screenshot-provable  
2\. Closest to money already spent  
3\. Fastest to show a visible win

\*\*One hard kill disqualifies a clinic. Zero soft signals are needed to deprioritize — soft  
signals route to a park tier, not a kill.\*\*

\---

\#\# 1\. Disqualification framework

\#\#\# 1.1 Hard kills — disqualify immediately, do not audit further

| \# | Signal | Why it's a kill |  
|---|--------|------------------|  
| 1 | No website \*\*and\*\* no Instagram \*\*and\*\* no Google Business Profile | Nothing to build automation on; no channel where leads even arrive |  
| 2 | Operating under 12 months (check oldest Google review date) | No established patient base, no dead pipeline to recover, unproven revenue to pay a retainer from |  
| 3 | Inbound volume under \~20 leads/month across all channels | Not enough pipeline for any system to act on |  
| 4 | Average treatment value below ₹25,000 | ROI math doesn't support the fee structure |  
| 5 | Committee or multi-partner sign-off required (no single decision-maker) | No one can say yes without external consensus |  
| 6 | Owner fully detached from lead operations — genuinely feels no pain | Nobody in the building experiences the problem you solve |  
| 7 | Primary ask is lead generation, ads, website redesign, or content | Marketing-agency client, not an ops-automation client. Refer out — builds goodwill |  
| 8 | No lead data exists anywhere (no WhatsApp history, phone register, diary) | The 90-day discovery audit has nothing to run on |  
| 9 | Clinic passes all six speed-to-lead tests (see Section 2\) | Functioning system already in place — no gap to sell into. Expect this to be rare (\~1 in 20\) |

\#\#\# 1.2 Park — not a kill, deprioritize and revisit with a specific approach

These were previously being treated as rejects. They are not disqualified — they need a  
different route or timing.

| Signal | Priority | Why park, not kill | Approach when revisited |  
|--------|----------|---------------------|---------------------------|  
| Mega founder-brand (very large personal following) | \*\*Medium\*\* | Longer sales cycle, harder access — but strong underlying fit (can score 9+/10 on other criteria) | Founder-capacity-protection pitch; nurture tier, not cold DM |  
| Existing but shallow automation (greeting-only auto-reply, no qualification) | \*\*High\*\* | Fit is strong, wedge is a depth upgrade rather than a new build | "The bot says hi — nobody finds out who's worth calling first" |  
| Front desk is the only reachable contact today | \*\*Medium\*\* | Founder-discovery failure, not a clinic failure | Route through Practo doctor listing, website team page, or LinkedIn before killing |

\#\#\# 1.3 Explicitly NOT disqualifiers

Do not kill a clinic for any of the following alone:

\- \*\*Not running Meta ads.\*\* Only removes the dead-lead-reactivation wedge; other wedges still apply. Also check Practo Prime / JustDial paid listings as a substitute "paying for leads" signal.  
\- \*\*Missing one channel\*\* (no website OR no Instagram), as long as WhatsApp plus at least one other channel exists.  
\- \*\*Messy or unused CRM/spreadsheet.\*\* Even poorly configured tracking still counts as infrastructure to build on.  
\- \*\*Strong surface reputation with no visible weakness.\*\* The mystery shop decides, not first impressions — polished clinics have still failed response-time tests.

\---

\#\# 2\. Speed-to-lead deep-audit SOP

\*\*When to run this:\*\* whenever a clinic passes the surface-level mystery shop (i.e. responds  
quickly to your initial enquiry). A fast reply alone does not mean the clinic is a kill — it  
means you run this SOP to find out \*where\* the fast responder actually breaks.

\*\*Framing:\*\* a fast responder is a strong prospect, not a weak one — the owner already  
believes leads are money. The goal of this SOP is not to disqualify them; it's to find the  
specific gap in an otherwise good instinct.

\#\#\# The six tests

| \# | Test | How to run it | If it fails → wedge |  
|---|------|----------------|----------------------|  
| 1 | \*\*Qualification\*\* | In their fast reply, did anyone ask about concern, treatment interest, budget, or timeline — or did they just answer your question? | Qualification \+ scoring layer |  
| 2 | \*\*Persistence\*\* | After their fast reply, go silent. Count follow-ups over the next 7–14 days. | Follow-up / nurture engine |  
| 3 | \*\*Quote decay\*\* | Ask for a price on a high-ticket procedure, receive it, then go quiet. Does anyone chase the quote? | Quote-decay follow-up |  
| 4 | \*\*After-hours\*\* | Send a second enquiry from a different number/channel at 10–11pm. | 24/7 instant-response automation |  
| 5 | \*\*Cross-channel\*\* | If WhatsApp was fast, DM the same clinic on Instagram and compare response time. | IG → WhatsApp handoff automation |  
| 6 | \*\*Booking friction\*\* | Book a consult, then reschedule last-minute. Does anyone proactively recover the slot? | No-show recovery |

\#\#\# Verdict

\- \*\*Fails one or more tests\*\* → the specific failure(s) identify the wedge(s) to lead with. Multiple failures are common; pick the entry wedge using the priority rule in Section 0\.  
\- \*\*Passes all six\*\* → hard kill (Section 1.1, \#9). Log and move on — do not keep probing.

\#\#\# Pitch angle when the clinic has a fast \*human\* responder (not automation)

Do not sell speed — they already have it and are usually proud of it. Sell \*\*fragility and  
cost\*\*:

\> "This works because of one person. What happens on their day off, after 8pm, or if they  
\> quit? And how much of their day goes to chasing people who were never going to book?"

Position the offer as: keep their existing closer, remove the manual chasing. Automation  
handles capture, qualification, reminders, and follow-up cadence; the human only enters  
once a lead is scored and warm. Nothing about how they close changes — this matches  
your managed-infrastructure positioning.

\---

\#\# 3\. Signal → wedge routing table

| Signal combination | Entry wedge | Opening frame | Priority |  
|---|---|---|---|  
| Ads ✓ · response slow or none | Dead-lead reactivation | "You already paid for these leads. They're dying in your inbox." | Very high |  
| Ads ✓ · fast first reply · no qualification, no follow-up | Follow-up and nurture engine | "You won the first 5 minutes and lost the next 14 days." | Very high |  
| Ads ✓ · no website · thin GBP (low reviews) · fast human reply | Review engine first, infra second | "Your ads send strangers to a thin profile — trust leaks before the DM ever arrives." | High |  
| Ads ✓ · greeting-only auto-reply · no qualification questions | Qualification \+ scoring upgrade | "The bot says hi. Nobody finds out who's worth calling first." | High |  
| No ads · website ✓ · high reviews · slow or no response | Instant response \+ organic capture | "Your reputation markets for free. Your inbox kills what it earns." | Very high |  
| No ads · high review count but last review months old | Review reactivation agent | "Your best patients left quietly. The proof engine stalled months ago." | Medium |  
| No ads · multi-session treatments (PRP, laser, aligners) · 12+ months operating | Dead-patient reactivation | "These people already trusted you enough to walk in once. They're sitting in your WhatsApp history." | High |  
| Practo Prime / JustDial paid listing · slow response | Dead-lead reactivation (aggregator) | "You pay Practo for enquiries, then leave them on read. Same leak, different bill." | High |  
| WhatsApp fast · Instagram DMs slow or silent | IG → WhatsApp handoff automation | "Half your enquiries land on the phone nobody's holding." | Medium |  
| Reviews mention booking friction, waits, or ghosting after payment | No-show recovery | "Every empty chair this month was a booked patient last week." | Medium |  
| High-ticket quote given, never chased afterward | Quote-decay follow-up | "An unchased ₹1.5L quote is the most expensive silence in the clinic." | High |  
| Fast human speed-caller · manual chasing · one person holds it all | Systematize the hustle | "Keep your closer. Remove the chasing. What happens after 8pm, or on their day off?" | Very high |  
| Mega founder brand · overflow signals (delayed DMs, solo-doctor bottleneck) | Founder capacity protection | "You solved attention. The leak is between the DM and the chair. Protect the founder's calendar." | Medium (park) |  
| Front desk is the only reachable contact today | — (access problem, not offer problem) | Route via Practo listing / website team page / LinkedIn before approaching | Medium (park) |  
| Multiple breaks present at once | Earliest provable break wins | Enter on one wedge only; full Revenue OS is the expansion, never the opener | Follows the single highest-priority row that applies |

\*\*Priority key:\*\* Very high \= mystery-shop and send this week · High \= queue within the  
current batch · Medium \= park, revisit once very-high/high queue is worked through ·  
(Any hard-kill combination from Section 1.1 does not enter this table at all.)

\---

\#\# 4\. Applying this to clinic audits — schema tagging

When completing a clinic's research dossier (Section 6 intelligence schema), add two  
fields at the end of the audit:

\- \*\*\`funnel\_break\_stage\`\*\* — the earliest Revenue OS stage where the funnel breaks. Use  
  one of: \`Response Speed\` / \`Qualification\` / \`Follow-up Persistence\` / \`Quote Chase\` /  
  \`Booking / No-show\` / \`Post-consult\` / \`Reviews\` / \`Reactivation\` / \`None (pass)\`.  
\- \*\*\`recommended\_entry\_sku\`\*\* — the wedge from Section 3 that corresponds to the break  
  stage above.

This turns every audit into a direct pointer into this document, rather than requiring the  
wedge to be re-derived from scratch per clinic. If a clinic hits a hard kill (Section 1.1),  
skip both fields and mark the audit \`Disqualified\` with the specific kill reason instead.

\---

\#\# Change log  
\- v1 — initial draft combining disqualification framework, speed-to-lead SOP, and signal-to-wedge routing table with priority tiers.  
